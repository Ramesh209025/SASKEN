/**
* MAin Configuration file.
* Configuration of Router, Securty, i18N, etc should be done here
* @author: banuprakashc@yahoo.co.in
*/

(function(){
	var ng = angular.module("MainModule",
		["ngRoute", "ngCookies", "CustomerModule","CustomDirectives","ServiceModule","authenticationApp"]);

	ng.config(function($routeProvider) {
		$routeProvider
		.when("/", {
			'templateUrl' :'app/page/home.html'
		})
		.when("/customers", {
			'templateUrl': 'app/page/customer.html'
		})
		.when("/orders", {
			'templateUrl' : 'app/page/order.html'
		})
		.when('/login',
		{
			'templateUrl' : 'app/page/login.html',
			'controller' : 'LoginController',
			'controllerAs' : 'vm'
		})
		.otherwise("/")
	}).run(run);

	function run($rootScope, $location, $cookieStore, $http) {
        $rootScope.globals = $cookieStore.get('globals') || {};
        if ($rootScope.globals.currentUser) {
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata; // jshint ignore:line
        }

        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            var restrictedPage = $.inArray($location.path(), ['/login', '/register']) === -1;
            var loggedIn = $rootScope.globals.currentUser;
            if (restrictedPage && !loggedIn) {
                $location.path('/login');
            }
        });
    }
})();