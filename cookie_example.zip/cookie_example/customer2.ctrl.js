/**
* Customer Controller module
* @author banuprakashc@yahoo.co.in
* @version 1.0
*/
(function(){
	var ng = angular.module("CustomerModule",["CustomDirectives","ServiceModule"]);
	
	ng.controller('LoginController',
			function($location, AuthenticationService) {
				(function initController() {
					// reset login status
					AuthenticationService.clearCredentials();
				})();

				this.login = function() {
					AuthenticationService.login(this.username, this.password,
							function(response) {
								if (response.success) {
									AuthenticationService.setCredentials(
											this.username, this.password);
									$location.path('/');
								} else {
									alert(response.message);
									$location.path('/login');
								}
							});
				};

	});


	ng.controller("CustomerMenuController",function($rootScope,$scope) {
		$scope.searchText = "";
		$scope.updateCustomerView = function() {
			$rootScope.$broadcast("customers_change",$scope.searchText);
		}
	});

	ng.controller("CustomerListController", function($scope,CustomerService) {
		$scope.customers = [];
		var customerData = [];
		CustomerService.getCustomers().then(function(data) {
			customerData = data.data;
			$scope.customers = customerData;
		});

		$scope.$on("customers_change",function(evt,txt) {
			var result = [];
			customerData.forEach(function(cust) {
				if((cust.firstName.toUpperCase().indexOf(txt.toUpperCase()) >= 0)
					||
					(cust.lastName.toUpperCase().indexOf(txt.toUpperCase()) >= 0)) {
					result.push(cust);
				}
			});
			$scope.customers = result;
		});


		$scope.delete = function(customer) {
			$scope.customers.splice($scope.customers.indexOf(customer),1);
			CustomerService.deleteCustomer(customer.id).then(function(){
				// you can redirect or display message....
			});
		}

	});
})();


