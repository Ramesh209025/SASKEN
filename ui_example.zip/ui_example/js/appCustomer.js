var routerApp = angular.module('routerApp', [ 'ui.router', 'ngCookies','CustomerApp' ]);

routerApp.config(function($stateProvider, $locationProvider, $urlRouterProvider) {
	$urlRouterProvider.otherwise('/login');
	$stateProvider
	.state('home', {
		url : '/home',
		template : 'Home Sweet Home!!!!'
	})
	.state('customers', {
		url : '/customers',
		templateUrl : 'partials/onlyCustomers.html'
	})
	// nested list 
	.state('customers.orders', {
		url : '/orders/:id',
		templateUrl : 'partials/order-of-customer.html',
		controller : 'CustomerOrderController'
	})
	// PAGE AND MULTIPLE NAMED VIEWS =================================
	.state('customers_orders', {
		url : '/customers_orders',
		views : {
			'' : {
				templateUrl : 'partials/customer-orders.html'
			},
			'customers@customers_orders' : {
				controller : 'CustomerController',
				templateUrl : 'partials/customers.html'
			},
			'orders@customers_orders' : {
				templateUrl : 'partials/table-data.html',
				controller : 'CustomerController'
			}
		}
	});
    
});
 