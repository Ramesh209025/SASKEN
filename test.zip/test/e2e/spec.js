// spec.js
describe('Protractor Demo App', function() {
   
	beforeEach(function() {
		browser.get('http://localhost:9000/customer3.html');
     //    browser.wait(function() {
       //     return browser.executeScript('return !!window.angular');
       // }, 5000); // 5000 is the timeout in millis
	});
    
	it('should have a title', function() {
	//	browser.get('http://localhost:8080/customer3.html');
		expect(browser.getTitle()).toEqual('Sample App');
	});
    
	it('should have a customers', function() {
		var customers = element.all(by.repeater('customer in customers'));
		customers.then(function(result) {
			console.log("Records....." + result.length);
			expect(result.length).toBeGreaterThan(1);
			expect(customers.count()).toEqual(6);
		});
	});
	
/*	it('search King customers', function() {
		var searchText = element(by.model('searchText'));
		// var searchBtn = element(by.id('Searc'));
		searchText.sendKeys('King');
		var searchId = element(by.id('st'));
		searchId.keypress();
		var customers = element.all(by.repeater('customer in customers'));
		customers.then(function(result) {
			console.log("King Records....." + result.length);
			expect(result.length).toBeGreaterThan(1);
			expect(customers.count()).toEqual(11);
		});
		// browser.pause();
		// browser.debugger();
		});
	
      describe('Customer list view', function() {

    beforeEach(function() {
      browser.get('customer2.html');
    });
*/

    it('should filter the customer list as a user types into the filter text box', function() {

     
      //var query = element(by.model('filterTxt'));
      var query = element(by.id('st'));
       query.sendKeys('Rao');
     //  query.sendKeys(protractor.Key.TAB);
      
     // query.actions().sendKeys('Kumar').perform();
       //query.perform();
        var customerList = element.all(by.repeater('customer in customers'));
        customerList.then(function(result) {
			console.log("Filtered Records....." + result.length);
			expect(result.length).toBe(2);
		});
       // browser.pause();
        //  expect(customerList.count()).toBe(2);
        //  query.clear();
        //  query.sendKeys('Suresh').perform();
        //  expect(customerList.count()).toBe(1);
    });
  });
//});


/*

*/