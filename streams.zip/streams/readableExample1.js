    	
     
    var fs = require('fs');
    var readableStream = fs.createReadStream('readableExample1.js');
    var content = '';
     
    readableStream.on('data', function(chunk) {
        content += chunk;
    });
     
    readableStream.on('end', function() {
        console.log(content);
    });



