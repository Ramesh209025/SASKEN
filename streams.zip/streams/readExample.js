	
	var fs = require("fs");
	var fileName = "../helloWorld/index.html";

	fs.readFile(fileName, function(err, data) {
	  // the data is passed to the callback in the second argument
	  console.log(data);
	});

