	
	var fs = require("fs");
	var fileName = "test.txt";

	fs.open(fileName, 'w', function(err, fd) {
  		if(err) throw err;
  		
  		var buf = new Buffer('Hello World\n');
  		
  		fs.write(fd, buf, 0, buf.length, null, function(err, written, buffer) {
    		if(err) throw err;

    		console.log(err, written, buffer); 
    		//null 12 <Buffer 48 65 6c 6c 6f 20 57 6f 72 6c 64 0a>
    		
    		fs.close(fd, function() {
      			console.log('Done');
    		});
  		});
	});


