	
	var fs = require("fs");
	var fileName = "readExample.js";

	fs.open(fileName, 'r', function(err, fd) {
  		 if(err) throw err;
      var buf = new Buffer(100);
      fs.read(fd, buf, 0, buf.length, null, 
        function(err, bytesRead, buffer) {
          if(err) throw err;
           debugger;
          console.log(bytesRead, buffer.toString());

          fs.close(fd, function() {
            console.log('Done');
          });
        });
   });

  


