/*
* service js for RESTful services
* @author:banuprakashc@yahoo.co.in
*/

(function(){
angular.module("customer_service",[]);
angular.module("customer_service")
	.service("CustomerService", function($http,$q){

	this.getCustomers = function() {
		var deferred = $q.defer();
		$http.get("http://localhost:3000/customers")
			.then(function(result){
				deferred.resolve(result);
			}, function(result){
				deferred.reject(result);
			});
		return deferred.promise;
	};

	this.getCustomer = function(id) {
		var deferred = $q.defer();
		$http.get("http://localhost:3000/customers/"+id)
			.then(function(result){
				deferred.resolve(result);
			}, function(result){
				deferred.reject(result);
			});
		return deferred.promise;
	};

	this.addCustomer = function(customer) {
		var deferred = $q.defer();
		$http.post("http://localhost:3000/customers", customer)
			.then(function(result){
				deferred.resolve(result);
			}, function(result){
				deferred.reject(result);
			});
		return deferred.promise;
	}; 

	this.updateCustomer = function(id,customer) {
		var deferred = $q.defer();
		$http.put("http://localhost:3000/customers/"+id, customer)
			.then(function(result){
				deferred.resolve(result);
			}, function(result){
				deferred.reject(result);
			});
		return deferred.promise;
	};

	this.deleteCustomer = function(id) {
		var deferred = $q.defer();
		$http.delete("http://localhost:3000/customers/"+id)
			.then(function(result){
				deferred.resolve(result);
			}, function(result){
				deferred.reject(result);
			});
		return deferred.promise;
	};  
});

})();