/*
* Main Configuration file
* @author:banuprakashc@yahoo.co.in
*/

(function(){
	angular.module("main_app",
		["ngRoute","customer_app",
		"custom_directive","customer_service","authentication_app"]);

	angular.module("main_app").config(function($routeProvider){
		$routeProvider
		.when("/",{
			templateUrl :'app/page/home.html'
		})
		.when("/customer",{
			templateUrl :'app/page/customer.html'
		})
		.when("/order",{
			templateUrl :'app/page/order.html',
			controller : function($scope) {
				$scope.orders = "Actual orders fetched from Order services..";
			}
		})
		.when('/login',
		{
			'templateUrl' : 'app/page/login.html',
			'controller' : 'LoginController',
			'controllerAs' : 'vm'
		})
		.otherwise("/")
	}).run(check);

	function check($rootScope, $location, $cookieStore, $http) {
        $rootScope.globals = $cookieStore.get('globals') || {};
        $rootScope.$on('$locationChangeStart', function () {
            var restrictedPage = $.inArray($location.path(), ['/login', '/register']) === -1;
            var loggedIn = $rootScope.globals.currentUser;
            if (restrictedPage && !loggedIn) {
                $location.path('/login');
            }
        });
    }
})();