(function(){
	/* 
		declate a module "customer_app"
		[] < -- dependencies
	*/
	var ng = angular.module("customer_app",
		["custom_directive","customer_service"]);
	
	ng.controller('LoginController',
			function($location, AuthenticationService) {
				(function initController() {
					// reset login status
					AuthenticationService.clearCredentials();
				})();

				this.login = function() {
					AuthenticationService.login(this.username, this.password,
							function(response) {
								if (response.success) {
									AuthenticationService.setCredentials(
											this.username, this.password);
									$location.path('/');
								} else {
									alert(response.message);
									$location.path('/login');
								}
							});
				};

	});

	/*
	 CustomerMenuController for handling
	 CardView, ListView menu and Filtering
	*/

	ng.controller("CustomerMenuController",function($rootScope,$scope){
		$scope.searchText = "";
		$scope.filterCustomers = function() {
			$rootScope.$broadcast("filter_event",$scope.searchText);
		}
	});

	/* CustomerListController for
	 handling Card View and List view
	*/
	ng.controller("CustomerListController", 
  						function($scope,CustomerService){
		$scope.customers = [];
		var customersData = [];

		CustomerService.getCustomers().then(function(result){
			$scope.customers = result.data;
			customersData = result.data;
		});

		$scope.editMode = false;

		/* listen to "filter_event" */
		$scope.$on("filter_event", function(evt, txt) {
			var result = [];
			customersData.forEach(function(customer) {
				if((customer.firstName.toUpperCase().indexOf(txt.toUpperCase()) >= 0)
					||
				   (customer.lastName.toUpperCase().indexOf(txt.toUpperCase()) >= 0)) {
					result.push(customer);
				}
			});
			$scope.customers = result;
		});


		$scope.deleteCustomer = function(customer) {
			$scope.customers.splice($scope.customers.indexOf(customer),1);
			// $http.delete(URL/id);
			CustomerService.deleteCustomer(customer.id).then(function(){
				// nothing doing for now
			});

		}

		$scope.currentCustomer = null;
		$scope.editForm = function(customer) {
			$scope.currentCustomer = customer;
			$scope.editMode = true;
		}

		$scope.updateCustomer = function() {
			// $http.put(....); send the update info to server
			$scope.editMode = false;
			CustomerService
				.updateCustomer($scope.currentCustomer.id,
					$scope.currentCustomer).then(function(){
				// nothing doing for now
			});
		}
	});
})();