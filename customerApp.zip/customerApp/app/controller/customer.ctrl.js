(function(){
	/* 
		declate a module "customer_app"
		[] < -- dependencies
	*/
	var ng = angular.module("customer_app",["custom_directive"]);
	/*
	 CustomerMenuController for handling
	 CardView, ListView menu and Filtering
	*/

	ng.controller("CustomerMenuController",function($rootScope,$scope){
		$scope.searchText = "";
		$scope.filterCustomers = function() {
			$rootScope.$broadcast("filter_event",$scope.searchText);
		}
	});

	/* CustomerListController for
	 handling Card View and List view
	*/
	ng.controller("CustomerListController", function($scope){
		$scope.customers = customersData;
		$scope.editMode = false;

		/* listen to "filter_event" */
		$scope.$on("filter_event", function(evt, txt) {
			var result = [];
			customersData.forEach(function(customer) {
				if((customer.firstName.toUpperCase().indexOf(txt.toUpperCase()) >= 0)
					||
				   (customer.lastName.toUpperCase().indexOf(txt.toUpperCase()) >= 0)) {
					result.push(customer);
				}
			});
			$scope.customers = result;
		});


		$scope.deleteCustomer = function(customer) {
			$scope.customers.splice($scope.customers.indexOf(customer),1);
			// $http.delete(URL/id);
		}

		$scope.currentCustomer = null;
		$scope.editForm = function(customer) {
			$scope.currentCustomer = customer;
			$scope.editMode = true;
		}

		$scope.updateCustomer = function() {
			// $http.put(....); send the update info to server
			$scope.editMode = false;
		}
	});

	var customersData = [
		  {
			 "id":1,"firstName":"Rajesh","lastName":"Sharma","gender":"male",
			 "orders": [
			          {"product":"iPhone 6","price":56000.00,"quantity":1},
			          {"product":"Reynolds Pen","price":45.66,"quantity":3}
			          ]
		 },
		 {
			 "id":2,"firstName":"Suresh","lastName":"Sharma","gender":"male",
			 "orders": [
			          {"product":"Moto G","price":12990.00,"quantity":1}
			          ]
		 },
		 {
			 "id":3,"firstName":"Anitha","lastName":"Kumar","gender":"female",
			 "orders": [
			          {"product":"iPhone 6","price":56000.00,"quantity":1},
			          {"product":"Reynolds Pen","price":45.66,"quantity":3}
			          ]
		 },
		 {
			 "id":4,"firstName":"Karthik","lastName":"Kumar","gender":"male",
			 "orders": [
			          {"product":"Samsung WM","price":35000.00,"quantity":1},
			          {"product":"LG Micro Oven","price":22000.00,"quantity":1}
			          ]
		 },
		 {
			 "id":5,"firstName":"Sunita","lastName":"Gowda","gender":"female" 
		 }
		 ];
})();