/**
* Directive for creating a card view
* @author:banuprakashc@yahoo.co.in
* @version: 1.0
*/

(function() {
	angular.module("custom_directive",[]);

	angular.module("custom_directive").directive("cardView", 
	function(){
		return 	{
			restrict : 'EA',
			templateUrl : 'app/template/card.view.tmpl.html'
		};
	});
})();